/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author guillermogotre
 */
public class PruebaNapakalaki {
    static ArrayList<Monster> monstruos = new ArrayList();
    
    public static ArrayList<Monster> nivelMayorDiez(){
        ArrayList<Monster> m = new ArrayList();
        for(int i=0; i<monstruos.size(); i++)
            if(monstruos.get(i).getCombatLevel() >= 10)
                m.add(monstruos.get(i));
        return m;
    }
    
    public static ArrayList<Monster> soloPerdidaNiveles(){
        ArrayList<Monster> m = new ArrayList();
        BadConsequence bc;
        for(int i=0; i<monstruos.size(); i++){
            bc = monstruos.get(i).getBadConsequence();
            if(bc.getLevels() > 0 &&
               bc.getSpecificHiddenTreasures().isEmpty() &&
               bc.getSpecificVisibleTreasures().isEmpty() &&
               bc.getNHiddenTreasures() == 0 &&
               bc.getNVisibleTreasures() == 0)
                m.add(monstruos.get(i));
        }
        return m;
    }
    
    public static ArrayList<Monster> ganarNivelMayorUno(){
        ArrayList<Monster> m = new ArrayList();
        for(int i=0; i<monstruos.size(); i++)
            if(monstruos.get(i).getPrize().getLevel() > 1)
                m.add(monstruos.get(i));
        return m;
    }
    
    public static ArrayList<Monster> perdidaTesoro(TreasureKind tk){
        ArrayList<Monster> m = new ArrayList();
        for(int i=0; i<monstruos.size(); i++)
            if(monstruos.get(i).getBadConsequence().getSpecificHiddenTreasures().contains(tk) ||
               monstruos.get(i).getBadConsequence().getSpecificVisibleTreasures().contains(tk))
                m.add(monstruos.get(i));
        return m;
    }
    
    //EXAMEN

    public void printReconciliated(){
        ArrayList<String> jugadores = new ArrayList();
        jugadores.add("Ana");
        jugadores.add("José");
        jugadores.add("María");
        Napakalaki game = Napakalaki.getInstance();
        game.initGame(jugadores);
        for ( Player jugador:game.getPlayers() ){
            jugador.tryMyselfReconciationWithMyEnemy();
            System.out.println("Jugador: " + jugador.getName() +",\n"
                    + " enemigo: " +jugador.getEnemy().getName() + "\n"
                    + "reconciliados: " +jugador.isReconciliated());
        }
        
    }

    //EXAMEN
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        printReconciliated();
        
    }
}
