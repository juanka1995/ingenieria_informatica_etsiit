/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author guillermogotre
 */
public class BadConsequence {
    final static int MAXTREASURES = 10;
    private String text;
    private int levels;
    private int nVisibleTreasures;
    private int nHiddenTreasures;
    private boolean death;
    private ArrayList<TreasureKind> specificHiddenTreasures = new ArrayList();
    private ArrayList<TreasureKind> specificVisibleTreasures = new ArrayList();
        
    
    public BadConsequence(String text, int levels, int nVisible, int nHidden){
        this.text = text;
        this.levels = levels;
        this.nVisibleTreasures = nVisible;
        this.nHiddenTreasures = nHidden;
    }
    
    public BadConsequence(String text, boolean death){
        this.text = text;
        this.levels = Player.MAXLEVEL;
        this.nVisibleTreasures = MAXTREASURES;
        this.nHiddenTreasures = MAXTREASURES;
        this.death = death;
    }
    
    public BadConsequence(String text, int levels, 
            ArrayList<TreasureKind> tVisible, ArrayList<TreasureKind> tHidden){
        this.text = text;
        this.levels = levels;
        this.specificVisibleTreasures = tVisible;
        this.specificHiddenTreasures = tHidden;
    }
    
    public boolean isEmpty(){
        return (
                (nVisibleTreasures == 0)&&
                (nHiddenTreasures == 0)&& 
                specificHiddenTreasures.isEmpty() && 
                specificVisibleTreasures.isEmpty()
                );
    }
    
    public String getText() {
        return text;
    }

    public int getLevels() {
        return levels;
    }

    public int getNVisibleTreasures() {
        return nVisibleTreasures;
    }

    public int getNHiddenTreasures() {
        return nHiddenTreasures;
    }

    public boolean isDeath() {
        return death;
    }

    public ArrayList<TreasureKind> getSpecificHiddenTreasures() {
        return specificHiddenTreasures;
    }

    public ArrayList<TreasureKind> getSpecificVisibleTreasures() {
        return specificVisibleTreasures;
    }
    
    public void substractVisibleTreasure(Treasure t){
        if(nVisibleTreasures == 0 && nHiddenTreasures == 0){
            if(specificVisibleTreasures.contains(t.getType()))
                specificVisibleTreasures.remove(t.getType());
        }
        else
            nVisibleTreasures = Math.max(0, nVisibleTreasures-1);
    }
    
    public void substractHiddenTreasure(Treasure t){
        if(nVisibleTreasures == 0 && nHiddenTreasures == 0){
            if(specificHiddenTreasures.contains(t.getType()))
                specificHiddenTreasures.remove(t.getType());
        }
        else
            nHiddenTreasures = Math.max(0,nHiddenTreasures-1);
    }
    
    public BadConsequence adjustToFitTreasureLists(ArrayList<Treasure> v, ArrayList<Treasure> h){
        BadConsequence nuevo;
        int nOneHand = 0;
        if (nHiddenTreasures > 0 || nVisibleTreasures > 0 ) {
            nuevo = new BadConsequence(this.text, this.levels, Math.min(this.nVisibleTreasures, v.size()), Math.min(this.nHiddenTreasures, h.size()));
        }
        else if (!specificHiddenTreasures.isEmpty() || !specificVisibleTreasures.isEmpty()){
            ArrayList<TreasureKind> v2 = new ArrayList();
            ArrayList<TreasureKind> h2 = new ArrayList();
            // Calculo el numero de ONEHAND ocultos
            for ( TreasureKind type:this.specificHiddenTreasures )
                if(type == TreasureKind.ONEHAND)
                    nOneHand++;
            for ( Treasure treasure:h ) {
                if(specificHiddenTreasures.contains(treasure.getType()) && treasure.getType() != TreasureKind.ONEHAND){
                    h2.add(treasure.getType());
                }
                else if (specificHiddenTreasures.contains(treasure.getType()) && treasure.getType() == TreasureKind.ONEHAND && nOneHand > 0){
                    h2.add(treasure.getType());
                    nOneHand--;
                }
            }
            nOneHand = 0;
            // Calculo el numero de ONEHAND visibles
            for ( TreasureKind type:this.specificVisibleTreasures )
                if(type == TreasureKind.ONEHAND)
                    nOneHand++;
            for ( Treasure treasure:v ) {
                if(specificVisibleTreasures.contains(treasure.getType()) && treasure.getType() != TreasureKind.ONEHAND){
                    v2.add(treasure.getType());
                }
                else if (specificVisibleTreasures.contains(treasure.getType()) && treasure.getType() == TreasureKind.ONEHAND && nOneHand > 0){
                    v2.add(treasure.getType());
                    nOneHand--;
                }
            }
            nuevo = new BadConsequence(this.text, this.levels, v2, h2);
        }
        else{
            return this;
        }
        return nuevo;
    }

    @Override
    public String toString() {
        return "BadConsequence{" + "text=" + text + ", levels=" + levels + ", nVisibleTreasures=" + nVisibleTreasures + ", nHiddenTreasures=" + nHiddenTreasures + ", death=" + death + ", specificHiddenTreasures=" + specificHiddenTreasures + ", specificVisibleTreasures=" + specificVisibleTreasures + '}';
    }
    
    
}
