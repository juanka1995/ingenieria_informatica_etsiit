/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

/**
 *
 * @author jcarlosruiz95
 */
public class Reconciliation {
    private Dice kairos = Dice.getInstance();
    private Player enemy;
    private Player player;
    public Reconciliation(Player aPlayer,Player enemy){
        this.player = aPlayer;
        this.enemy = enemy;
    }
    public boolean prayedForMyEnemy(){
        return player.getLevels() >= enemy.getLevels();
    }
    public boolean helpedAndGotHelpedByMyEnemy(){
        boolean resultado = false;
        if (kairos.nextNumber() % 3 == 1) {
            resultado = true;
        }
        return resultado;
    }
    public boolean saidIAmSorryToMyEnemy(){
        boolean resultado = false;
        if (kairos.nextNumber() % 2 != 0 && enemy.getLevels() == 1) {
            resultado = true;
        }
        return resultado;
    }
}
