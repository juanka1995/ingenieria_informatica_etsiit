/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author juanka1995
 */
public class PruebaNapakalaki {

    static ArrayList<Monster> monstruos = new ArrayList();  
    public static void CreateMonsters(){
        monstruos.add(new Monster(
                "3 Byakhees de bonanza",
                8,
                new BadConsequence("Pierdes tu armadura visible y otra oculta",
                    0, 
                    new ArrayList(Arrays.asList(TreasureKind.ARMOR)),
                    new ArrayList(Arrays.asList(TreasureKind.ARMOR))),
                new Prize(2,1)));
        
        monstruos.add(new Monster(
                "Tenochtitlan",
                2,
                new BadConsequence("Embobados con el lindo primigenio te descartas de tu casco visible",
                    0, 
                    new ArrayList(Arrays.asList(TreasureKind.HELMET)),
                    new ArrayList()),
                new Prize(1,1)));
        
        monstruos.add(new Monster(
                "El sopor de Dunwich",
                2,
                new BadConsequence("El primordial bostezo contagioso. Pierdes el calzado visible",
                    0, 
                    new ArrayList(Arrays.asList(TreasureKind.SHOES)),
                    new ArrayList()),
                new Prize(1,1)));

        monstruos.add(new Monster(
                "Demonios de Magaluf",
                2,
                new BadConsequence("Te atrapan para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta",
                    0, 
                    new ArrayList(Arrays.asList(TreasureKind.ONEHAND)),
                    new ArrayList(Arrays.asList(TreasureKind.ONEHAND))),
                new Prize(4,1)));
        
        monstruos.add(new Monster(
                "El gorrón en el umbral",
                13,
                new BadConsequence("Pierdes todos tus tesoros visibles",0,Integer.MAX_VALUE,0),
                new Prize(3,1)));
        
        monstruos.add(new Monster(
                "H.P. Munchcraf",
                6,
                new BadConsequence("Pierdes la armadura visible",
                    0,
                    new ArrayList(Arrays.asList(TreasureKind.ARMOR)),
                    new ArrayList()),
                new Prize(2, 1)));
        
        monstruos.add(new Monster(
                "Necrofago",
                13,
                new BadConsequence("Sientes bichos bajo la ropa. Descarta tu armadura visible",
                    0,
                    new ArrayList(Arrays.asList(TreasureKind.ARMOR)),
                    new ArrayList()),
                new Prize(1,1)));
        
        monstruos.add(new Monster(
                "El rey de rosado",
                11,
                new BadConsequence("Pierdes 5 niveles y 3 tesoros visibles",5,3,0),
                new Prize(3,2)));
        
        monstruos.add(new Monster(
                "Flecher",
                2,
                new BadConsequence("Toses los pulmones y pierdes 2 niveles", 2, 0, 0),
                new Prize(1,1)));
        
       monstruos.add(new Monster(
                "Los hondos",
                8,
                new BadConsequence("Estos monstruos resultan bastante superficiales y te aburren mortalmente. Estás muerto", true),
                new Prize(2, 1)));
       
        monstruos.add(new Monster(
                "Semillas Cthulhu",
                4,
                new BadConsequence("Pierdes 2 niveles y 2 tesoros ocultos", 2,0,2),
                new Prize(2,1)));
        
        monstruos.add(new Monster(
                "Dameargo", 
                1, 
                new BadConsequence("Te intentas esquaquear. Pierdes una mano visible", 
                    0,
                    new ArrayList(Arrays.asList(TreasureKind.ONEHAND)),
                    new ArrayList()),
                new Prize(2, 1)));
        
        monstruos.add(new Monster(
                "Pollipólipo volante",
                3,
                new BadConsequence("Da mucho asquito. Pierdes 3 niveles", 3,0,0),
                new Prize(2,1)));

        monstruos.add(new Monster(
                "Yskhtihyssq-Goth",
                14,
                new BadConsequence("No le hace gracia que pronuncien mal su nombre. Estás mueto", true),
                new Prize(3,1)));
        
        monstruos.add(new Monster(
                "Familia feliz",
                1,
                new BadConsequence("La familia te atrapa. Estás muerto", true),
                new Prize(3, 1)));
        
        monstruos.add(new Monster(
                "Roboggoth",
                8,
                new BadConsequence("La quinta directiva primaria te obliga a perder 2 niveles y un tesoro 2 manos visible", 
                    2,
                    new ArrayList(Arrays.asList(TreasureKind.BOTHHANDS)), 
                    new ArrayList()),
                new Prize(2,1)));
        
        monstruos.add(new Monster(
                "El espía sordo",
                5,
                new BadConsequence(
                        "Te asusta en la noche. Pierdes un casco visible", 
                        0,
                        new ArrayList(Arrays.asList(TreasureKind.HELMET)),
                        new ArrayList()),
                new Prize(1,1)));
        
        monstruos.add(new Monster(
                "Tongue",
                19,
                new BadConsequence("Menudo suste te llevas. Pierdes 2 niveles y 5 tesoros visibles",2,5,0),
            new Prize(2,1)));
        
        monstruos.add(new Monster(
                "Bicéfalo",
                21,
                new BadConsequence(
                    "Te faltan manos para tanta cabeza. Pierdes 3 niveles y tus tesoros visibles de las manos", 
                    3,
                    new ArrayList(Arrays.asList(TreasureKind.BOTHHANDS, TreasureKind.ONEHAND)), 
                    new ArrayList()),
                new Prize(2,1)));
        
//        monstruos.add(new Monster(
//                "Monstruo Examen",
//                14,
//                    new BadConsequence("Te suma 1 punto en el examen de practicas. Pierdes 1 nivel, 5 tesoros visibles y la armadura oculta.",
//                    1, 5,
//                    new ArrayList(Arrays.asList(TreasureKind.ARMOR))),
//                new Prize(1,2)));
        
    }
    
    public static ArrayList CombatLevelBigger10(){
        ArrayList<Monster> CombatLevelBigger10 = new ArrayList();
        for(Monster m : monstruos){
            if(m.getCombatLevel() > 10)
                CombatLevelBigger10.add(m);
        }
        return CombatLevelBigger10;
    }
    
    public static ArrayList OnlyLoseLevels(){
        ArrayList<Monster> OnlyLoseLeveles = new ArrayList();
        for(Monster m : monstruos){
            if(m.getBadConsequence().getLevels() > 0 && 
               m.getBadConsequence().getNHiddenTreasures() == 0 &&
               m.getBadConsequence().getNVisibleTreasures() == 0){
                    OnlyLoseLeveles.add(m);
            }
        }
        return OnlyLoseLeveles;
    }
    
    public static ArrayList WinLevelBigger1(){
        ArrayList<Monster> WinLevelBigger1 = new ArrayList();
        for(Monster m : monstruos){
            if(m.getPrize().getlevel() > 1)
                WinLevelBigger1.add(m);
        }
        return WinLevelBigger1;
    }
    
    public static ArrayList LoseSpecificTreasures(TreasureKind treasure){
        ArrayList<Monster> LoseSpecificTreasures = new ArrayList();
        for(Monster m : monstruos){
            if(m.getBadConsequence().getSpecificHiddenTreasures().contains(treasure) || 
               m.getBadConsequence().getSpecificVisibleTreasures().contains(treasure)){
                    LoseSpecificTreasures.add(m);
            }
        }
        return LoseSpecificTreasures;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //CreateMonsters();

//        System.out.println(CombatLevelBigger10());
//        System.out.println(OnlyLoseLevels());
//        System.out.println(WinLevelBigger1());
//        System.out.println(LoseSpecificTreasures(TreasureKind.ARMOR));
//        System.out.println(LoseSpecificTreasures(TreasureKind.ONEHAND));
//        System.out.println(LoseSpecificTreasures(TreasureKind.BOTHHANDS));
//        System.out.println(LoseSpecificTreasures(TreasureKind.HELMET));
        //System.out.println(LoseSpecificTreasures(TreasureKind.SHOES));
        
        System.out.println(Prueba.getInstance().probarJuego());
    }
}
