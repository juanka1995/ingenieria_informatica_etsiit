/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author jcarlosruiz95
 */
public class Prueba {
    private static final Prueba instance = new Prueba();
    ArrayList<Treasure> tesoros = new ArrayList();
    
    private Prueba(){}
    
    public String probarJuego(){
        for (int i = 0; i < 144; i++) {
            int n = (Dice.getInstance().nextNumber()%3)+1;
            tesoros.add(new Treasure("ONEHAND-"+i, n, TreasureKind.ONEHAND));
        }
        String resultado = tesoros.toString();
        return resultado;
    }
    
    public static Prueba getInstance(){
        return instance;
    }
}
