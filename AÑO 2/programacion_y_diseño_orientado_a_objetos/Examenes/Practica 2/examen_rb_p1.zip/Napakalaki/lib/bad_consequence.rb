#encoding:utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'treasure_kind.rb'

class BadConsequence
  
  attr_reader :text
  attr_reader :levels
  attr_reader :nVisibleTreasures
  attr_reader :nHiddenTreasures
  attr_reader :death
  attr_reader :specificVisibleTreasures
  attr_reader :specificHiddenTreasures
  private_class_method :new
  @@MAX_TREASURES = 10
  
  def initialize(text,levels,nVisibleTreasures,nHiddenTreasures,specificVisibleTreasures,specificHiddenTreasures,death)
    @text = text
    @levels = levels
    @nVisibleTreasures = nVisibleTreasures
    @nHiddenTreasures = nHiddenTreasures
    @specificVisibleTreasures = specificVisibleTreasures
    @specificHiddenTreasures = specificHiddenTreasures
    @death = death
  end
  
  def self.getMaxTreasures
    return @@MAX_TREASURES
  end
  
  def self.newLevelNumberOfTreasures (aText, levels,nVisibleTreasures, nHiddenTreasures)
    new(aText,levels,nVisibleTreasures,nHiddenTreasures,[],[],false)
  end
  
  def self.newLevelSpecificTreasures (aText,levels,specificVisibleTreasures, specificHiddenTreasures)
    new(aText,levels,0,0,specificVisibleTreasures,specificHiddenTreasures,false)
  end
  
  def self.newDeath (aText)
    new(aText,0,0,0,[],[],true)
  end
  
  def isEmpty
    return ((@nHiddenTreasures == 0) && (@nVisibleTreasures == 0) && (@specificHiddenTreasures.empty?) && (@specificVisibleTreasures.empty?))
  end
  
  def substractVisibleTreasure(t)
    
  end
  
  def substractHiddenTreasure(t)
    
  end
  
  def adjustToFitTreasureLists(v,h)
    
  end
  
  def to_s
    "BadConsequence{text=#{@text}, levels=#{@levels}, nVisibleTreasures=#{@nVisibleTreasures},
     nHiddenTreasures=#{@nHiddenTreasures}, @specificVisibleTreasures=#{@specificVisibleTreasures}, 
     specificHiddenTreasures=#{@specificHiddenTreasures}, death=#{@death}"
  end
  
end
