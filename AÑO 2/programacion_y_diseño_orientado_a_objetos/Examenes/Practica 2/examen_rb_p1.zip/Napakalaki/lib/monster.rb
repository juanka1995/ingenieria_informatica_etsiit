#encoding:utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'bad_consequence.rb'
require_relative 'prize.rb'

class Monster
  
  attr_reader :name
  attr_reader :combatLevel
  attr_reader :badConsequence
  attr_reader :prize
  
  def initialize(name,level,bc,prize)
    @name = name
    @combatLevel = level
    @badConsequence = bc
    @prize = prize
  end
  
  def getLevelsGained
    return @prize.level
  end
  
  def getTreasuresGained
    return @prize.treasures
  end
  
  def to_s
    "Monster{name=#{@name}, combatLevel=#{@combatLevel}, prize=#{@prize}, badConsequence=#{@badConsequence}\n"
  end
  
end
