#encoding:utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "prize.rb"
require_relative "monster.rb"
require_relative "bad_consequence.rb"
require_relative "treasure_kind.rb"
require_relative "player.rb"
require_relative "dice.rb"
require_relative "card_dealer.rb"

class PruebaNapakalaki
  
  @@monsters = Array.new
  @@MAX_VALUE = 5
  
  def self.createMonster
      
    @@monsters << Monster.new(
      "Byakhees de bonanza",
      8,
      BadConsequence.newLevelSpecificTreasures(
        "Pierdes tu armadura visible y otra oculta",
        0,
        [TreasureKind::ARMOR], 
        [TreasureKind::ARMOR]),
      Prize.new(2,1))

    @@monsters << Monster.new(
      "Tenochtitlan",
      2,
      BadConsequence.newLevelSpecificTreasures(
        "Embobados con el lindo primigenio te descartas de tu casco visible",
        0,
        [TreasureKind::HELMET], 
        []),
      Prize.new(1,1))

    @@monsters << Monster.new(
    "El sopor de Dunwich",
    2,
    BadConsequence.newLevelSpecificTreasures(
      "El primordial bostezo contagioso. Pierdes el calzado visible",
      0,
      [TreasureKind::SHOES], 
      []),
    Prize.new(1,1))

    @@monsters << Monster.new(
    "Demonios de Magaluf",
    2,
    BadConsequence.newLevelSpecificTreasures(
      "Te atrapa para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta",
      0,
      [TreasureKind::ONEHAND], 
      [TreasureKind::ONEHAND]),
    Prize.new(4,1))

    @@monsters << Monster.new(
      "El gorrón en el umbral",
      13,
      BadConsequence.newLevelNumberOfTreasures("Pierdes todos tus tesoros visibles",0,@@MAX_VALUE,0),
      Prize.new(3,1))

    @@monsters << Monster.new(
    "H.P. Munchcraft",
    6,
    BadConsequence.newLevelSpecificTreasures(
      "Pierdes la armadura visible",
      0,
      [TreasureKind::ARMOR], 
      []),
    Prize.new(2,1))    

    @@monsters << Monster.new(
    "Necrófago",
    13,
    BadConsequence.newLevelSpecificTreasures(
      "Sientes bichos bajo la ropa.Descarta la armadura visible",
      0,
      [TreasureKind::ARMOR], 
      []),
    Prize.new(1,1))   

    @@monsters << Monster.new(
      "El rey de rosado",
      11,
      BadConsequence.newLevelNumberOfTreasures("Pierdes 5 niveles y 3 tesoros visibles",5,3,0),
      Prize.new(3,2))    

    @@monsters << Monster.new(
      "Flecher",
      2,
      BadConsequence.newLevelNumberOfTreasures("Toses los pulmones y pierdes 2 niveles",2,0,0),
      Prize.new(1,1))   

    @@monsters << Monster.new(
      "Los hondos",
      8,
      BadConsequence.newDeath("Estos monstruos resultan bastante superficiales y te aburren mortalmente. Estas muerto"),
      Prize.new(2,1))    

    @@monsters << Monster.new(
      "Semillas Cthulhu",
      4,
      BadConsequence.newLevelNumberOfTreasures("Pierdes 2 niveles y 2 tesoros ocultos",2,0,2),
      Prize.new(2,1))

    @@monsters << Monster.new(
    "Dameargo",
    1,
    BadConsequence.newLevelSpecificTreasures(
      "Te intentas escaquear. Pierdes una mano visible",
      0,
      [TreasureKind::ONEHAND], 
      []),
    Prize.new(2,1))

    @@monsters << Monster.new(
      "Pollipolipo volante",
      3,
      BadConsequence.newLevelNumberOfTreasures("Da mucho asquito. Pierdes 3 niveles",3,0,0),
      Prize.new(2,1))

    @@monsters << Monster.new(
      "Yskhtihyssg-Goth",
      14,
      BadConsequence.newDeath("No le hace gracia que pronuncien mal su nombre. Estas muertos"),
      Prize.new(3,1))

    @@monsters << Monster.new(
      "Familia feliz",
      1,
      BadConsequence.newDeath("La familia te atrapa. Estas muerto"),
      Prize.new(3,1))

    @@monsters << Monster.new(
    "Roboggoth",
    8,
    BadConsequence.newLevelSpecificTreasures(
      "La quinta directiva primaria te obliga a perder dos niveles y un tesoro 2 manos visible",
      2,
      [TreasureKind::BOTHHANDS], 
      []),
    Prize.new(2,1))

    @@monsters << Monster.new(
    "El espia sordo",
    5,
    BadConsequence.newLevelSpecificTreasures(
      "Te asustas en la noche. Pierdes un casco visible",
      0,
      [TreasureKind::HELMET], 
      []),
    Prize.new(1,1))

    @@monsters << Monster.new(
      "Tongue",
      19,
      BadConsequence.newLevelNumberOfTreasures("Menudo susto te llevas. Pierdes 2 niveles y 5 tesoros visibles",2,5,0),
      Prize.new(2,1))    

    @@monsters << Monster.new(
    "Bicéfalo",
    21,
    BadConsequence.newLevelSpecificTreasures(
      "Te faltan manos para tanta cabeza. Pierdes 3 niveles y tus tesoros visibles de las manos",
      3,
      [TreasureKind::ONEHAND , TreasureKind::BOTHHANDS], 
      []),
    Prize.new(2,1))
    
  end
  
  def self.CombatLevelBigger10
    combatLevelBigger10 = Array.new
    @@monsters.each do |m|
      if(m.combatLevel > 10)
        combatLevelBigger10 << m
      end
    end
    return combatLevelBigger10
  end
  
  def self.OnlyLoseLevels
    onlyLoseLevels = Array.new
    @@monsters.each do |m|
      if(m.badConsequence.levels != 0 &&
         m.badConsequence.nVisibleTreasures == 0 &&
         m.badConsequence.nHiddenTreasures == 0)
            onlyLoseLevels << m
      end
    end
    return onlyLoseLevels
  end
  
  def self.WinLevelBigger1
    winLevelBigger1 = Array.new
      @@monsters.each do |m|
        if(m.prize.level > 1)
#          winLevelBigger1 << m
        end
      end
    return winLevelBigger1
  end
  
  def self.LoseSpecificTreasures(treasure)
    loseSpecificTreasures = Array.new
    @@monsters.each do |m|
      if(m.badConsequence.specificVisibleTreasures.include?(treasure) ||
         m.badConsequence.specificHiddenTreasures.include?(treasure))
            loseSpecificTreasures << m
      end
    end
    return loseSpecificTreasures
  end
  
  PruebaNapakalaki.createMonster
  
#  puts PruebaNapakalaki.CombatLevelBigger10
#  puts PruebaNapakalaki.OnlyLoseLevels
#  puts PruebaNapakalaki.WinLevelBigger1
#  puts PruebaNapakalaki.LoseSpecificTreasures(TreasureKind::ARMOR)
#  puts PruebaNapakalaki.LoseSpecificTreasures(TreasureKind::ONEHAND)
#  puts PruebaNapakalaki.LoseSpecificTreasures(TreasureKind::BOTHHAND)
#  puts PruebaNapakalaki.LoseSpecificTreasures(TreasureKind::HELMET)
  puts PruebaNapakalaki.LoseSpecificTreasures(TreasureKind::SHOES)
  
end