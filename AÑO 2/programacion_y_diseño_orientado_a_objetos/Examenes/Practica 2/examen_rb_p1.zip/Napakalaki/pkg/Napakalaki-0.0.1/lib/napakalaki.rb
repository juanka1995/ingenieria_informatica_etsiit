#encoding:utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require 'singleton.rb'
require_relative 'card_dealer.rb'
require_relative 'combat_result.rb'
require_relative 'monster.rb'
require_relative 'player.rb'

class Napakalaki
  
  include Singleton
  
  def initialize
    @currentPlayer
    @players = Array.new
    @dealer = CardDealer.instance
    @currentMonster
  end
  
  def initPlayers(names)
    @players = names
  end
  
  def nextPlayer
    
  end
  
  def nextTurnAllowed
    
  end
  
  def setEnemies
    
  end
  
  def developCombat
    
  end
  
  def discardVisibleTreasures(treasures)
    
  end
  
  def discardHiddenTreasures(treasures)
    
  end
  
  def makeTreasuresVisible(treasures)
    
  end
  
  def initGame(players)
    
  end
  
  def getCurrentPlayer
    
  end
  
  def getCurrentMonster
    
  end
  
  def nextTurn
    
  end
  
  def endOfGame(result)
    
  end
  
  private :initPlayers, :nextPlayer, :nextTurnAllowed, :setEnemies
  
end
