#encoding:utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'dice.rb'
require_relative 'bad_consequence.rb'
require_relative 'treasure.rb'
require_relative 'combat_result.rb'
require_relative 'card_dealer.rb'

class Player
  
  attr_reader :name
  @@MAX_LEVEL = 10
  
  def initialize(name)
    @name = name
    @level
    @dead = true
    @canISteal = true
    @hiddenTreasures = Array.new
    @visibleTreasures = Array.new
    @enemy
    @pendingBadConsequence = Array.new
  end
  
  def getMaxLevel
    return @@MAX_LEVEL
  end
  
  def bringToLife
    @dead = false
  end
  
  def getCombatLevel
    bonus = 0
    @visibleTreasures.each do |i|
      bonus = bonus + i.bonus
    end
    return (@level + bonus)
  end
  
  def incrementLevels(l)
    if((@level +l) > @@MAX_LEVEL)
      @level = @@MAX_LEVEL
    else
      level = level + l
    end
  end
  
  def decrementLevels(l)
    if((@level - l) < 0)
      @level = 0
    else
      @level = @level - l
    end
  end
  
  def setPendingBadConsequence(b)
    @pendingBadConsequence = b
  end
  
  def applyPrize(m)
    
  end
  
  def applyBadConsequence(m)
    
  end
  
  def canMakeTreasureVisible(t)
    
  end
  
  def howManyVisibleTreasures(tKind)
    numberOftKind = 0
    @visibleTreasures.each do |i|
      if(i.getType == tKind)
        numberOftKind = numberOftKind + 1
      end
    end
    return numberOftKind
  end
  
  def dielfNoTreasures
    @dead = true
  end
  
  def isDead
    return @dead
  end
  
  def getHiddenTreasures
    
  end
  
  def getVisibleTreasures
    
  end
  
  def combat(m)
    
  end
  
  def makeTreasureVisible(t)
    
  end
  
  def discardVisibleTreasure(t)
    
  end
  
  def discardHiddenTreasure(t)
    
  end
  
  def validState
    return ((@hiddenTreasures.size < 5) && (@pendingBadConsequence.isEmpty));
  end
  
  def initTreasures
    
  end
  
  def getLevels
    return @level
  end

  def stealTreasure
    
  end
  
  def setEnemy(enemy)
    @enemy = enemy
  end
  
  def giveMeATreasure
    
  end
  
  def canISteal
    return @canISteal
  end
  
  def canYouGiveMeATreasure
    return !@hiddenTreasures.empty?
  end
  
  def haveStolen
    @canISteal = false
  end
  
  def discardAllTreasures
    
  end
  
  private :bringToLife, :getCombatLevel, :incrementLevels, :decrementLevels, :setPendingBadConsequence, :applyPrize, :applyBadConsequence, :canMakeTreasureVisible, :howManyVisibleTreasures, :dielfNoTreasures, :giveMeATreasure, :canYouGiveMeATreasure, :haveStolen
  
end