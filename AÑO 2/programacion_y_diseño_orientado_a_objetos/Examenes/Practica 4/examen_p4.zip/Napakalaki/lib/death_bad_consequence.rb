#encoding: utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

class DeathBadConsequence < NumericBadConsequence
  attr_reader :death
  
  def initialize(text,death)
    super(text,Player.maxLevel,@@MAXTREASURES,@@MAXTREASURES)
    @death = death
  end
  
  def adjustToFitTreasureLists(v,h)
    super(v,h)
  end
  
  def to_s
    super + ", death=#{@death}"
  end
  
end
