#encoding: utf-8
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

class Monster
  attr_reader :name, :combatLevel, :prize, :badConsequence, :levelChangeAgainstCultistPlayer
  def initialize(name,combatLevel,bc,prize,ic)
    @name=name
    @combatLevel=combatLevel
    @prize=prize
    @badConsequence=bc
    @levelChangeAgainstCultistPlayer = ic
  end
  
  #EXAMEN
  def newGoodMonster(monster)
    @name = monster.name
    @combatLevel = monster.combatLevel
    @prize = monster.prize
    @badConsequence = NumericBadConsequence.new("No hay mal rollo",0,0,0)
    @levelChangeAgainstCultistPlayer = monster.levelChangeAgainstCultistPlayer
  end
  #EXAMEN
  
  def self.Monster(n,l,bc,p)
    new(n,l,bc,p,0)
  end
  
  #EXAMEN
  def shouldConvert
    should = false
    dice = Dice.instance
    if (dice.nextNumber == 2)
      should = true
    end
    should
  end
  #EXAMEN
  
  def self.MonsterSec(n,l,bc,p,ic)
    new(n,l,bc,p,ic)
  end
  
  def getCombatLevelAgainstCultistPlayer
    combatLevel + @levelChangeAgainstCultistPlayer
  end
  
  def getLevelsGained
    @prize.level
  end
  
  def getTreasuresGained
    @prize.treasures
  end
  
  def to_s
    "Monster{name=#{@name}, combatLevel=#{(@combatLevel+@levelChangeAgainstCultistPlayer)}, prize=#{@prize.to_s}, badConsequence=#{@badConsequence.to_s}}";
  end
end
