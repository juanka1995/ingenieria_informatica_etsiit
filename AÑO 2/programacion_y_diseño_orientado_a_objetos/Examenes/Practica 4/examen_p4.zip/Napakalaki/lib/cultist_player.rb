# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "player.rb"

class CultistPlayer < Player
  @@totalCultistPlayers = 0
  def initialize(p,c)
    super.newPlayerCultist(p)
    @@totalCultistPlayer = @@totalCultistPlayer + 1
    @myCultistCard = c
  end
  
  def combatLevel
    lv = super
    lv + 0.7*lv + @myCultistCard.getGainedLevels*getTotalCultistPlayers
  end
  
  def getOponentLevel(m)
    m.getCombatLevelAgainstCultistPlayer
  end
  
  def shouldConvert
    false
  end
  
  def giveMeATreasure
    getVisibleTreasures.at(rand(getVisibleTreasures.size + 1))        
  end
  
  def canYouGiveMeATreasure
    enemy.getVisibleTreasures.empty?
  end
  
  def totalCultistPlayers
    @@totalCultistPlayers
  end
  
end
