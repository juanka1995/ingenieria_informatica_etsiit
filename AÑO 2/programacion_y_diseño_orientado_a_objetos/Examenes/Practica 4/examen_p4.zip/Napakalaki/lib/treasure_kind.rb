#encoding: utf-8

module TreasureKind
    ARMOR=:armor
    ONEHAND=:onehand
    BOTHHANDS=:bothhands
    HELMET=:helmet
    SHOES=:shoes
end
