var searchData=
[
  ['tolower',['toLower',['../class_traductor.html#a746af8812dd1a75e66fece798d151a8c',1,'Traductor']]],
  ['traductor',['Traductor',['../class_traductor.html',1,'Traductor'],['../class_traductor.html#a9723a49b5b82689bff2b827ca2da3f45',1,'Traductor::Traductor()']]],
  ['traductor_2eh',['traductor.h',['../traductor_8h.html',1,'']]]
];
