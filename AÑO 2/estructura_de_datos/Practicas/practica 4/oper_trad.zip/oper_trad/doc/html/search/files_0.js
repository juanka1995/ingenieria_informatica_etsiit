var searchData=
[
  ['frase_2eh',['frase.h',['../frase_8h.html',1,'']]]
];
