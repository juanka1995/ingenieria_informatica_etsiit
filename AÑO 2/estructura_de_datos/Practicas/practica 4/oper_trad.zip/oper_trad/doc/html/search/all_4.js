var searchData=
[
  ['find',['find',['../class_traductor.html#a8992959f19a78b5cd0a96a5227170d31',1,'Traductor']]],
  ['frase',['Frase',['../class_frase.html',1,'Frase'],['../class_frase.html#a6af6ccf07cac65950917bc81f5e03c95',1,'Frase::Frase()'],['../class_frase.html#afec194c2d5d169d5e9a22333a595188b',1,'Frase::Frase(string ff)']]],
  ['frase_2eh',['frase.h',['../frase_8h.html',1,'']]]
];
