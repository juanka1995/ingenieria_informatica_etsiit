var searchData=
[
  ['insertardestino',['InsertarDestino',['../class_frase.html#a3581733d29ed02b57904543fc0385833',1,'Frase']]],
  ['insertarfrase',['InsertarFrase',['../class_traductor.html#a2f7bd688f7724944c9093970fd32c5eb',1,'Traductor']]]
];
