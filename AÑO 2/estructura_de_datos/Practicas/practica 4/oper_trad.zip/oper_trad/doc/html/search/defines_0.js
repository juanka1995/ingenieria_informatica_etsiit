var searchData=
[
  ['_5ftraductor_5fh_5f',['_TRADUCTOR_H_',['../traductor_8h.html#a5c5fd73d6bda181573e4d3d3a314a290',1,'traductor.h']]]
];
