var searchData=
[
  ['getdestino',['GetDestino',['../class_frase.html#a8e402ede6cd22f97aa3b76678ae87805',1,'Frase']]],
  ['getorigen',['GetOrigen',['../class_frase.html#a57a41696b44dbe4941957225fcc6e789',1,'Frase']]],
  ['gettraducciones',['GetTraducciones',['../class_traductor.html#ad80103faf9d79807b3d1c6718ce7d14b',1,'Traductor']]]
];
