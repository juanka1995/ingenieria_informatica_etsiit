var searchData=
[
  ['end',['end',['../class_frase.html#afc004f077e8bca4f76b4c7caca4c2641',1,'Frase::end()'],['../class_traductor.html#a149165eba2b47a9e5942369cb139be9b',1,'Traductor::end()']]]
];
