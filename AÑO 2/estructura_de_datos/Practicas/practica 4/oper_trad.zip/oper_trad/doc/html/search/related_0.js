var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_frase.html#ae7c5f5b2357a6fe4a2824a1590be3fa3',1,'Frase::operator&lt;&lt;()'],['../class_traductor.html#a78120f314da935ebbe07cf3e4f3b26d7',1,'Traductor::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../class_traductor.html#a60ee2a06b6560b2edec8ad3fb223e903',1,'Traductor']]]
];
