var searchData=
[
  ['traductor',['Traductor',['../class_traductor.html',1,'']]]
];
