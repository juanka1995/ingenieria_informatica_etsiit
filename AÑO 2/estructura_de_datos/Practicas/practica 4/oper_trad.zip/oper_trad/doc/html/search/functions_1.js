var searchData=
[
  ['const_5fiterator',['const_iterator',['../class_frase_1_1const__iterator.html#a21d9c41b9f2757077ed19a169693dafa',1,'Frase::const_iterator::const_iterator()'],['../class_frase_1_1const__iterator.html#a20edeba3614e63e4954c0d72881fdaf7',1,'Frase::const_iterator::const_iterator(const vector&lt; string &gt;::iterator &amp;i)'],['../class_traductor_1_1const__iterator.html#ac864564e8a72514922903f6c553c3986',1,'Traductor::const_iterator::const_iterator()'],['../class_traductor_1_1const__iterator.html#af325de50c35d0c4478216061e870cd1c',1,'Traductor::const_iterator::const_iterator(const map&lt; string, Frase, comparador &gt;::const_iterator i)']]]
];
