var searchData=
[
  ['begin',['begin',['../class_frase.html#a700666d5980f370b8c646f7d5e71de1c',1,'Frase::begin()'],['../class_traductor.html#a4af21754c460def90bc2a9e11166fde2',1,'Traductor::begin()']]]
];
