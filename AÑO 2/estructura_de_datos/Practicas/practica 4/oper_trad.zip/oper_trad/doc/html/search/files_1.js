var searchData=
[
  ['traductor_2eh',['traductor.h',['../traductor_8h.html',1,'']]]
];
